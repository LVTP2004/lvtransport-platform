# Historia de LVTransport: lectura completa de los commits, parte1

## Cobertura exacta

Se leyeron **los mensajes completos de los 469 commits** de `commits-part-1.json`, no solo sus títulos: registros 1–100, 101–200, 201–300, 301–400 y 401–469, sin truncamientos de esos bloques. El archivo abarca desde el9 de mayo2026 a las 11:57:47 UTC hasta el 12 de mayo a las 12:50:43 UTC. El último registro es el commit que actualiza el informe de #100; el merge de #100 cae fuera del corte de este archivo y pertenece al tramo siguiente.

Se correlacionaron con las **100 PR #1–100**, cuyas descripciones se leyeron completas en la nota hermana. La lectura de mensajes no equivale a una auditoría de todos los parches ni de todos los logs de pruebas. Se inspeccionaron selectivamente archivos/diffs de #48, #54, #59, #86 y #100. No se ejecutó código del repositorio ni se modificó GitHub/runtime. Esta nota describe el estado histórico de mayo, no certifica el despliegue actual.

Fuente local: `commits-part-1.json`, SHA256 `eeeb012097f14d1c75296cd88856b25a276f915eed5a6a166feb42d7eefc7b4f`. Clon bare `lvtransport.git`; main auditado `a7708afbdcba16dcef7e146c4501297daab3bdfd`.

## 1. Qué significan los números

| Medida del tramo | Resultado | Interpretación |
|---|---:|---|
| SHA únicos |469|Objetos de historia, no 469 funciones distintas|
| Ancestros de main |226|Alcanzables desde el main auditado|
| Fuera de esos ancestros |243|Incluye variantes de historia y trabajo en otra rama|
| Raíces sin padres |2|Mismo árbol inicial; SHA e historia diferentes|
| Commits con un padre |248|Cambios, configuración, documentación y reintentos, entre otras cosas|
| Merges con dos padres |219|Integración de ramas/PR; no función nueva por sí mismos|
| Mensajes textualmente distintos |232|Tampoco equivalen a 232 funcionalidades|
| Grupos misma fecha de commit + mismo mensaje |243|226 parejas y17 registros sin pareja dentro del tramo|

Las dos raíces son [228ea820](https://github.com/LVTP2004/lvtransport-platform/commit/228ea820fb9e3a5011e11b33b636f0c063f084a4) y [2bbfa637](https://github.com/LVTP2004/lvtransport-platform/commit/2bbfa637b179a540e70ef6dd746e62d9f72ccf37). Ambas apuntan al tree `d335bc512d27ae3a599f843d573d41478eb96050`. La segunda está en main. No se infiere la causa de la duplicación/reconstrucción de historia ni se asume que fue trabajo repetido.

En cada una de las 226 parejas hay un SHA alcanzable desde main y otro que no. La misma fecha y el mismo mensaje indican una relación histórica muy fuerte, pero no se usaron por sí solos para afirmar equivalencia de todos los árboles/parches. Las cifras globales del repositorio deben preservar el conteo por SHA y explicar esta duplicación, sin sumar los merges como entregas independientes.

Hay **190 mensajes de merge de PR** y **29 merges de ramas**. Por fecha UTC de commit, el tramo se distribuye así: 2026-05-09: 118, 2026-05-10: 56, 2026-05-11: 112, 2026-05-12: 183. La ordenación cronológica no sustituye el grafo de ancestros; una PR numerada antes puede integrarse después de otra.

## 2. Evolución que se puede reconstruir

### 9 de mayo: guardar el origen, fijar el plan y montar las interfaces

La historia comienza con creación de directorios, `.gitkeep`, documentación maestra y una copia del sitio previo. El commit [0f45f5e3](https://github.com/LVTP2004/lvtransport-platform/commit/0f45f5e351bdb46d965d350a0baf929d276cb182) guarda un backup de lvtransport.be; no prueba un despliegue nuevo. [9deb503a](https://github.com/LVTP2004/lvtransport-platform/commit/9deb503a1b4cc64fde445385b39d02f732b8a724), correlacionado con #1, establece documentación; [ce421f51](https://github.com/LVTP2004/lvtransport-platform/commit/ce421f51235d9873572883fb81b7cb8cde61de05), #2, audita el ZIP; [fda284f4](https://github.com/LVTP2004/lvtransport-platform/commit/fda284f4a8f824f4265ee75e8b54356232665a2d), #3, prepara migración.

Después se montan el monorepo, las tres apps React/Vite, paquetes de diseño, landing, booking, Admin y Driver (#4–10). Se añaden cimientos API, Firebase/realtime, mapas, pricing y auth (#11–18). Los commits tienen palabras como scaffold/architecture; las descripciones de PR confirman que gran parte era estructura y UI con ejemplos, no integración comercial terminada.

### 9–10 de mayo: intentos de despliegue separados del avance de producto

Hay una cadena directa que la lista de PR por sí sola no muestra bien: [a72ec4f7](https://github.com/LVTP2004/lvtransport-platform/commit/a72ec4f72017d02cd51e72ed0a46f24ca73b7b77) añade GitHub Actions auto deploy; siguen `Fix deploy workflow`, `password auth fixed`, `fix yaml syntax`, `fix port`, `hardcode port 22`, `trigger deploy`, `retry deploy`, `final retry` y [c55d2989](https://github.com/LVTP2004/lvtransport-platform/commit/c55d298964f6f5b71477c54bdb92000719600212) titulado `success retry`.

Estos mensajes acreditan trabajo y reintentos sobre la configuración. **El nombre `success retry` no es un recibo de Actions ni una comprobación del sitio en vivo.** No se inspeccionó configuración sensible ni se transcribieron claves. Es razonable separar esta historia de infraestructura del número de funciones de reservas entregadas.

### 10–11 de mayo: primer MONI, booking in-memory y reparación de la integración

El primer paquete MONI aparece en [7efc9b64](https://github.com/LVTP2004/lvtransport-platform/commit/7efc9b640a0ab5c1350fece7641dd485fabc5e47), #19: automatización determinista compartida de reservas. Las auditorías #21–23 piden un vertical slice completo, mientras #24–34 añaden pagos/notificaciones placeholder, reservas in-memory, realtime, rutas y auth. Los merges desde main hacia las ramas muestran convergencia técnica, pero no certifican su corrección.

El commit [fb31cb09](https://github.com/LVTP2004/lvtransport-platform/commit/fb31cb09a22654bf9f49805400c18e067ae254f3), #38, introduce otra función de MONI: asistente de reserva frontend multilingüe. Por la descripción completa sabemos que son módulos de heurísticas/intents/extracción/respuestas. El adjetivo AI en un nombre de rama no prueba un modelo conectado.

Los mensajes `restore valid booking app component`, `resolve merged App.tsx corruption`, `consolidate app bootstrap createApp export` y `use shared API base env fallback` corresponden a #35, #41, #42, #43 y confirman una fase real de reparación de código integrado. Las auditorías #36,#40,#52 proporcionan la evidencia de fallos, más fuerte que una interpretación basada en el número de commits.

### 11–12 de mayo: build, recovery/GPS y dos destinos de integración

#44–52 añaden replay/dedupe, persistencia cliente, ETA placeholder, ranking de conductores, pricing, mapa simulado, observabilidad y modo demo. El commit [c6fc33af](https://github.com/LVTP2004/lvtransport-platform/commit/c6fc33af737da1844a2a4407df878bd519dbeea5), #51, nombra explícitamente un modo de presentación para inversores. Es evidencia de prototipo intencionado.

#53–58 trabajan sobre `fix/production-build`. [044378e0](https://github.com/LVTP2004/lvtransport-platform/commit/044378e0cd185a940b05f70380347d57147a77b8), #54, cambia también el alcance del comando build. [a87412a6](https://github.com/LVTP2004/lvtransport-platform/commit/a87412a6879867a02824fda512d6695697741eeb), #59, integra la rama a main. Después continúa trabajo en esa rama (#60, #62–68) sin aparecer como ancestros del main actual auditado, mientras otras PR (#61, #69 en adelante) siguen el camino main. Esta bifurcación explica por qué leer «merged» sin mirar la base puede exagerar el estado de la entrega.

### 12 de mayo: expansión de operaciones, visión futura y conclusión explícita de QA

Los mensajes #69–80 cubren ETA, maps, dispatch, pricing, payments, business/VIP, analytics, Admin, alerts, PWA y automation. Se añaden además conceptos NTIV/BLS/Interim/LVTech/ecosistema (#81, #84, #85, #90, #91), expresamente no productivos según sus descripciones.

MONI da el salto documental hacia operaciones multiagente en [979cf63b](https://github.com/LVTP2004/lvtransport-platform/commit/979cf63b10e4f64907f404e33635c71762be71c1), #89. Son contratos/arquitectura con control humano. No consta aquí un runtime autónomo ni la interfaz Ask MONI Founder posterior.

La secuencia termina en planes de soft-launch, primer viaje, beta, demo y piloto; reparación de módulos API; y nuevos informes. El último commit leído, [8f060a69](https://github.com/LVTP2004/lvtransport-platform/commit/8f060a69ab4a2e416e37bb6e05873df63c6ee8e6), es la versión que está en los ancestros de main del informe de #100. El informe reconoce API/typecheck fallido, build de frontend válido y ausencia de certificación E2E, con score subjetivo 46/100. Es el cierre histórico respaldado, aunque muchos títulos previos suenen a preparación de producción.

## 3. Integraciones de rama que no deben confundirse con main

Estos 17 registros no tienen pareja fecha/mensaje dentro del tramo y no son ancestros del main auditado. Corresponden a ocho PR integradas en `fix/production-build` más un merge interno de esa rama. Se enumeran como evidencia de organización histórica; no se afirma que sus funciones no existan hoy por otros cambios.

| Orden | Commit | Tipo | Mensaje |
|---|---|---|---|
| 319 | [160744ede9](https://github.com/LVTP2004/lvtransport-platform/commit/160744ede9475462d63ecad9a422e5023ea381db) | cambio | Harden booking persistence and recovery in booking service |
| 320 | [5f2dcc062b](https://github.com/LVTP2004/lvtransport-platform/commit/5f2dcc062b649a15bbb35811ea4cdf156bf0bb48) | merge | Merge pull request #60 from leovargas-max/codex/implement-booking-persistence-and-recovery |
| 327 | [87c6d975df](https://github.com/LVTP2004/lvtransport-platform/commit/87c6d975dfc4a92bacfc2725a304efda73b5ea13) | cambio | api: centralize booking operational lifecycle state management |
| 328 | [edb80cd286](https://github.com/LVTP2004/lvtransport-platform/commit/edb80cd28670f0720c6c80d81cf9ac8a877c62ac) | merge | Merge pull request #62 from leovargas-max/codex/implement-centralized-state-management-for-booking |
| 329 | [6e2712974e](https://github.com/LVTP2004/lvtransport-platform/commit/6e2712974e12e204d9ad56b04d5ccc1238b77a11) | cambio | Implement realtime cross-panel booking synchronization |
| 330 | [56f203c54f](https://github.com/LVTP2004/lvtransport-platform/commit/56f203c54ff943d8fd8bbc0c7851c818a5a61d21) | merge | Merge pull request #63 from leovargas-max/codex/implement-cross-panel-operational-synchronization |
| 331 | [96e0d64c36](https://github.com/LVTP2004/lvtransport-platform/commit/96e0d64c36d32170b9ade752ceb21f87b0f34e74) | cambio | Add operational observability and realtime diagnostics |
| 332 | [74673d9a98](https://github.com/LVTP2004/lvtransport-platform/commit/74673d9a985d12e6470ba6bc8204803ab36115e4) | merge | Merge pull request #64 from leovargas-max/codex/implement-operational-observability-for-lv-transport |
| 333 | [6a714ab0cf](https://github.com/LVTP2004/lvtransport-platform/commit/6a714ab0cf221e3e9d469b145caebd31d61bcd49) | cambio | Harden production startup and realtime reconnect safety |
| 334 | [171cc838c4](https://github.com/LVTP2004/lvtransport-platform/commit/171cc838c4fc9f4787cde90c337960fe3f033dfa) | merge | Merge pull request #65 from leovargas-max/codex/implement-production-deployment-hardening |
| 335 | [516190c3ce](https://github.com/LVTP2004/lvtransport-platform/commit/516190c3cea4bd96007082ccbf7e8dd6e7d76623) | cambio | feat: add reconnect-safe realtime recovery flows |
| 336 | [f6dffcde4b](https://github.com/LVTP2004/lvtransport-platform/commit/f6dffcde4b62ae17d411cc1d6019afd63fc251bd) | merge | Merge pull request #66 from leovargas-max/codex/implement-operational-resilience-and-recovery-systems |
| 337 | [844e00ab68](https://github.com/LVTP2004/lvtransport-platform/commit/844e00ab686e0416231d1d88c06bb9917aa3a348) | cambio | Add live driver GPS sharing and admin tracking feed |
| 338 | [c646f327bb](https://github.com/LVTP2004/lvtransport-platform/commit/c646f327bb3fc9b068f1da9966a5f402bfe0adf0) | merge | Merge pull request #67 from leovargas-max/codex/implement-live-driver-gps-and-map-integration |
| 339 | [55b574ca87](https://github.com/LVTP2004/lvtransport-platform/commit/55b574ca87ba96b5b0e102cd8b599c941f8e7e9d) | cambio | feat(api): add reconnect-safe realtime driver telemetry pipeline |
| 340 | [dcf8598c7e](https://github.com/LVTP2004/lvtransport-platform/commit/dcf8598c7e2e12fbf220b43e35bba7afbaeb3ad0) | merge | Merge branch 'fix/production-build' into codex/implement-realtime-telemetry-for-lv-transport-platform |
| 341 | [4e9e7c62c3](https://github.com/LVTP2004/lvtransport-platform/commit/4e9e7c62c3bc0da2867f6089a0f6dca2e6922c42) | merge | Merge pull request #68 from leovargas-max/codex/implement-realtime-telemetry-for-lv-transport-platform |

## 4. Advertencias de interpretación sustentadas en archivos

1. El build raíz de #54 y siguientes comprende web/admin/driver. Las frases «build pasó» no son equivalentes a «API pasó». Fuente: [package.json de #54](https://github.com/LVTP2004/lvtransport-platform/blob/f33a418917af971e947c18fd38adbb5ec2a348a8/package.json).
2. La prueba API mencionada en #48 no tiene un script test en [package.json de ese head](https://github.com/LVTP2004/lvtransport-platform/blob/419d24aed0017f9ca49237db18b695589ed6ab4c/apps/api/package.json). Sin logs complementarios, no se certifica ese PASS.
3. #86 pasa a helpers de auth sin HMAC/PBKDF2 para eliminar dependencias Node en el browser. Los archivos históricos muestran una regresión de seguridad, aunque build de frontend pase: [jwt.service.ts](https://github.com/LVTP2004/lvtransport-platform/blob/3f2ec474220161a3e03b65b9aed6d21b984e46d0/packages/auth/src/security/jwt.service.ts) y [password-hash.service.ts](https://github.com/LVTP2004/lvtransport-platform/blob/3f2ec474220161a3e03b65b9aed6d21b984e46d0/packages/auth/src/security/password-hash.service.ts). No se extrapola al auth de noviembre.
4. Al comparar el diff de una PR antigua se debe usar su merge-base. Comparar directamente una base que avanzó con un head viejo puede aparentar borrados de cambios de otras ramas. Se comprobó #86 con cuatro archivos efectivos y #100 con un archivo documental efectivo.
5. [QA_OPERATIONAL_REGRESSION_REPORT.md de #100](https://github.com/LVTP2004/lvtransport-platform/blob/5faec84e5cc915be087ec7a99f0969b088249561/QA_OPERATIONAL_REGRESSION_REPORT.md) declara su método limitado: gates de compilación/tipos e inspección, sin backend staging integrado ni harness multiactor. Los planes de piloto de las PR vecinas no sustituyen esos resultados.

## 5. Qué falta fuera del alcance de este agente

Para el informe global hay que seguir los siguientes tramos antes de decidir qué defectos persistieron, qué prototipos se sustituyeron y cuándo aparecieron Founder OS/Ask MONI o el contrato actual de cinco superficies. Esta primera parte permite explicar el origen del producto, las varias acepciones iniciales de MONI y la deuda de integración; no permite diagnosticar por sí sola el sitio de noviembre.

La cobertura se puede reproducir con el JSON local y sus 469 mensajes completos. No se ha interpretado un recuento de objetos Git como un recuento de funcionalidades, ni un merge como recibo de despliegue o de viaje real.
