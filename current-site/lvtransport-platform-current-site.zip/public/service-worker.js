const CACHE_NAME = 'lvtransport-v70-final-hero-calculator';
const APP_SHELL = [
  '/index.html',
  '/tracking.html',
  '/assets/css/style.css',
  '/assets/js/config.js',
  '/assets/js/api.js',
  '/assets/js/common.js',
  '/assets/js/pricing.js',
  '/assets/js/booking.js',
  '/assets/js/chatbot.js',
  '/assets/img/hero-byd-virgen.webp',
  '/assets/img/hero-byd-virgen-mobile.webp'
];
self.addEventListener('install', (event) => { event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).catch(()=>{})); self.skipWaiting(); });
self.addEventListener('activate', (event) => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (url.hostname.includes('api.lvtransport.be')) return;
  if (event.request.mode === 'navigate' || /\.(html|css|js)$/.test(url.pathname)) {
    event.respondWith(fetch(event.request).then(res => {
      const clone = res.clone(); caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone)); return res;
    }).catch(() => caches.match(event.request)));
    return;
  }
  event.respondWith(caches.match(event.request).then(res => res || fetch(event.request)));
});
