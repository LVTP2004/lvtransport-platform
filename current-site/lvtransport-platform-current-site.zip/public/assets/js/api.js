(function(){
  const cfg = window.LV_CONFIG || {};
  const base = (cfg.API_BASE_URL || '').replace(/\/$/, '');
  function getToken(role){ return localStorage.getItem(`lv_${role}_token`) || ''; }
  function setToken(role, token){ if(token) localStorage.setItem(`lv_${role}_token`, token); }
  function clearToken(role){ localStorage.removeItem(`lv_${role}_token`); }
  async function request(path, options={}){
    const url = `${base}${path}`;
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    if(options.token) headers.Authorization = `Bearer ${options.token}`;
    const res = await fetch(url, { ...options, headers });
    const text = await res.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch { data = { ok:false, raw:text }; }
    if(!res.ok) throw Object.assign(new Error(data.message || data.error || `HTTP ${res.status}`), { status: res.status, data });
    return data;
  }
  async function health(){ return request('/health'); }
  async function login(role, email, password){ const data = await request('/api/auth/login', { method:'POST', body: JSON.stringify({role,email,password}) }); setToken(role, data.token); return data; }
  function sse(path, token){ const q = token ? `${path}${path.includes('?')?'&':'?'}token=${encodeURIComponent(token)}` : path; return new EventSource(`${base}${q}`); }
  window.LV_API = { base, request, health, login, getToken, setToken, clearToken, sse,
    estimate: payload => request('/api/pricing/estimate', { method:'POST', body:JSON.stringify(payload) }),
    createBooking: payload => request('/api/bookings', { method:'POST', body:JSON.stringify(payload) }),
    bookingByCode: code => request(`/api/bookings/code/${encodeURIComponent(code)}`),
    trackEvents: code => sse(`/api/bookings/code/${encodeURIComponent(code)}/events`),
    adminDashboard: token => request('/api/admin/dashboard', { token }),
    adminStatus: (token,id,status) => request(`/api/admin/bookings/${id}/status`, { method:'PATCH', token, body:JSON.stringify({status}) }),
    adminAssign: (token,id,driverId) => request(`/api/admin/bookings/${id}/assign`, { method:'POST', token, body:JSON.stringify({driverId}) }),
    driverBookings: token => request('/api/driver/bookings', { token }),
    driverAccept: (token,id) => request(`/api/driver/bookings/${id}/accept`, { method:'POST', token }),
    driverReject: (token,id) => request(`/api/driver/bookings/${id}/reject`, { method:'POST', token }),
    driverStatus: (token,id,status) => request(`/api/driver/bookings/${id}/status`, { method:'PATCH', token, body:JSON.stringify({status}) }),
    driverAvailability: (token,status) => request('/api/driver/status', { method:'PATCH', token, body:JSON.stringify({status}) }),
    driverLocation: (token,payload) => request('/api/driver/location', { method:'POST', token, body:JSON.stringify(payload) }),
    chat: message => request('/api/chatbot', { method:'POST', body:JSON.stringify({message}) }),
    publicSiteConfig: () => request('/api/public/site-config'),
    adminSaveSiteConfig: (token,payload) => request('/api/admin/site-config', { method:'POST', token, body:JSON.stringify(payload) })
  };
})();
