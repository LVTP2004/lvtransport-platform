(function(){
  const API = window.LV_API;
  const storageKey = 'lv_customer_token';
  const profileKey = 'lv_customer_profile';

  function token(){ return localStorage.getItem(storageKey) || ''; }
  function profile(){ try { return JSON.parse(localStorage.getItem(profileKey) || 'null'); } catch { return null; } }
  function saveSession(data){
    if(data && data.token) localStorage.setItem(storageKey, data.token);
    if(data && data.customer) localStorage.setItem(profileKey, JSON.stringify(data.customer));
    if(data && data.user) localStorage.setItem(profileKey, JSON.stringify(data.user));
    updateHeader();
    prefillBooking();
  }
  function clearSession(){ localStorage.removeItem(storageKey); localStorage.removeItem(profileKey); updateHeader(); }
  function setStatus(msg, type='info'){
    const el = document.getElementById('authStatus');
    if(!el) return;
    el.className = `auth-status ${type}`;
    el.textContent = msg || '';
  }
  function openAuth(mode='login'){
    const modal = document.getElementById('authModal');
    if(!modal) return;
    modal.classList.add('open');
    modal.setAttribute('aria-hidden','false');
    switchTab(mode);
  }
  function closeAuth(){
    const modal = document.getElementById('authModal');
    if(!modal) return;
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden','true');
    setStatus('');
  }
  function switchTab(mode){
    const isRegister = mode === 'register';
    document.getElementById('authTitle') && (document.getElementById('authTitle').textContent = isRegister ? 'Aanmelden' : 'Inloggen');
    document.querySelectorAll('[data-auth-tab]').forEach(btn => btn.classList.toggle('active', btn.dataset.authTab === mode));
    document.getElementById('loginForm')?.classList.toggle('hidden', isRegister);
    document.getElementById('registerForm')?.classList.toggle('hidden', !isRegister);
    setStatus('');
  }
  function updateHeader(){
    const p = profile();
    document.querySelectorAll('.auth-open').forEach(btn => {
      if(p){
        if(btn.dataset.authMode === 'login') { btn.textContent = 'Mijn ritten'; btn.onclick = () => location.href = 'account.html'; }
        if(btn.dataset.authMode === 'register') { btn.textContent = 'Uitloggen'; btn.onclick = () => { clearSession(); location.reload(); }; }
      } else {
        btn.onclick = null;
        if(btn.dataset.authMode === 'login') btn.textContent = 'Inloggen';
        if(btn.dataset.authMode === 'register') btn.textContent = 'Aanmelden';
      }
    });
  }
  function prefillBooking(){
    const p = profile();
    if(!p) return;
    const map = { name:p.name, email:p.email, phone:p.phone };
    Object.entries(map).forEach(([id,val]) => { const el=document.getElementById(id); if(el && !el.value && val) el.value=val; });
  }

  async function apiRegister(payload){
    if(!API) throw new Error('API niet beschikbaar');
    return API.request('/api/customers/register', { method:'POST', body:JSON.stringify(payload) });
  }
  async function apiLogin(payload){
    if(!API) throw new Error('API niet beschikbaar');
    return API.request('/api/customers/login', { method:'POST', body:JSON.stringify(payload) });
  }
  async function apiMe(){
    if(!API || !token()) return null;
    return API.request('/api/customers/me', { token: token() });
  }
  async function apiBookings(){
    if(!API || !token()) return { bookings: [] };
    return API.request('/api/customers/bookings', { token: token() });
  }

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.auth-open').forEach(btn => btn.addEventListener('click', (e) => { e.preventDefault(); const p = profile(); if(p && btn.dataset.authMode === 'login') return location.href='account.html'; if(p && btn.dataset.authMode === 'register'){ clearSession(); return location.reload(); } openAuth(btn.dataset.authMode || 'login'); }));
    document.querySelectorAll('[data-auth-close]').forEach(btn => btn.addEventListener('click', closeAuth));
    document.querySelectorAll('[data-auth-tab]').forEach(btn => btn.addEventListener('click', () => switchTab(btn.dataset.authTab)));

    document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
      e.preventDefault(); setStatus('Even geduld...');
      try{
        const data = await apiLogin({ email:loginEmail.value, password:loginPassword.value });
        saveSession(data); setStatus('Ingelogd. U kunt uw ritten bekijken.', 'success');
        setTimeout(() => location.href='account.html', 600);
      }catch(err){ setStatus(err.message || 'Login mislukt. Controleer e-mail en wachtwoord.', 'error'); }
    });
    document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
      e.preventDefault(); setStatus('Account wordt aangemaakt...');
      try{
        const data = await apiRegister({ name:registerName.value, email:registerEmail.value, phone:registerPhone.value, password:registerPassword.value });
        saveSession(data); setStatus('Account aangemaakt. Uw gegevens worden ingevuld in het reserveringsformulier.', 'success');
        setTimeout(closeAuth, 900);
      }catch(err){ setStatus(err.message || 'Aanmelden mislukt.', 'error'); }
    });

    updateHeader();
    prefillBooking();
  });

  window.LV_CUSTOMER_AUTH = { token, profile, clearSession, openAuth, apiMe, apiBookings };
})();
