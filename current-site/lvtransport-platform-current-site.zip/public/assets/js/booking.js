(function(){
  const { $, $all, escapeHtml, money, notify, whatsappUrl } = window.LV || {};
  const pricing = window.LV_PRICING;
  let latestEstimate = null;

  function payload(){ return {
    name: $('#name')?.value.trim(), phone: $('#phone')?.value.trim(), email: $('#email')?.value.trim(),
    pickup: $('#pickup')?.value.trim(), destination: $('#destination')?.value.trim(), date: $('#date')?.value,
    time: $('#time')?.value, passengers: $('#passengers')?.value, luggage: $('#luggage')?.value,
    serviceType: $('#serviceType')?.value, customerNotes: $('#customerNotes')?.value.trim(),
    fixedPrice: $('#fixedPrice')?.value || '', source:'website-v7-2-client'
  }; }
  function niceMoney(v){ return `€${Number(v || 0).toFixed(0)}`; }
  function renderEstimate(e){
    latestEstimate = e;
    const html = `<div class="price-main"><span>${e.fixed ? 'Richtprijs' : 'Prijsindicatie'}</span><strong>${niceMoney(e.low)} – ${niceMoney(e.high)}</strong></div><div class="price-sub">${e.distanceKm} km · ±${e.minutes} min · ${e.tariff}${e.fixed ? ' · populaire route' : ''}${e.needsControlTower ? ' · controle mogelijk' : ''}</div><small>Richtprijs. LV Transport controleert de definitieve prijs bij uitzonderlijke ritten.</small>`;
    if($('#pricePreview')) $('#pricePreview').innerHTML = html;
    if($('#smartPriceResult')) $('#smartPriceResult').innerHTML = html;
  }
  async function updateEstimate(){
    const data = payload();
    if(!data.pickup || !data.destination){
      const msg = '<strong>Vul vertrek en bestemming in</strong><span>Uw prijsindicatie verschijnt automatisch.</span>';
      if($('#pricePreview')) $('#pricePreview').innerHTML = '<span class="muted">Vul ophaaladres en bestemming in voor prijsindicatie.</span>';
      if($('#smartPriceResult')) $('#smartPriceResult').innerHTML = msg;
      return;
    }
    renderEstimate(await pricing.estimateSmart(data));
  }
  function dedupePlaces(items){
    const seen = new Set();
    return items.filter(p=>{
      if(!p || !p.name) return false;
      const key = (pricing.normalize ? pricing.normalize(p.name) : p.name.toLowerCase());
      if(seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0,10);
  }
  function remoteAddressLabel(feature){
    const props = feature?.properties || {};
    const parts = [props.name, props.street, props.housenumber, props.city || props.county, props.country].filter(Boolean);
    return parts.join(', ').replace(/, Belgium$/i, ', België');
  }
  async function remoteAddressSuggestions(query){
    const cfg = window.LV_CONFIG || {};
    if(!cfg.ADDRESS_AUTOCOMPLETE_URL || query.trim().length < 3) return [];
    try{
      const url = `${cfg.ADDRESS_AUTOCOMPLETE_URL}?q=${encodeURIComponent(query + ' Belgium')}&limit=6&lang=nl`;
      const ctrl = new AbortController();
      const timer = setTimeout(()=>ctrl.abort(), 1800);
      const res = await fetch(url, { signal: ctrl.signal });
      clearTimeout(timer);
      if(!res.ok) return [];
      const json = await res.json();
      return (json.features || []).map(f=>({
        name: remoteAddressLabel(f),
        type: 'adres',
        service: 'standard',
        km: 8,
        remote: true,
        note: 'Adresvoorstel'
      })).filter(p=>p.name);
    }catch{ return []; }
  }
  function attachSuggestions(input){
    const box = document.querySelector(`.suggestions[data-for="${input.id}"]`); if(!box) return;
    input.setAttribute('autocomplete','off');
    let requestId = 0;
    const popularDefaults = () => {
      const all = pricing.allAutocompletePlaces ? pricing.allAutocompletePlaces() : [];
      const names = (input.id === 'pickup' || input.id === 'calcPickup')
        ? ['Antwerpen centrum','Antwerpen-Berchem Station','Antwerpen-Centraal Station','Willem van Laarstraat 42, Berchem','Mechelen','Brussel Centrum']
        : ['Brussels Airport Zaventem','Charleroi Airport','Antwerpen Airport','Blankenberge','Schiphol Airport','Eindhoven Airport','Brugge','Rotterdam'];
      return names.map(n => all.find(p => p.name === n)).filter(Boolean).slice(0,8);
    };
    const draw = (items) => {
      box.innerHTML = items.map(p=>`<button type="button" data-value="${escapeHtml(p.name)}" data-price="${p.price || ''}" data-service="${p.service || ''}"><strong>${escapeHtml(p.name)}</strong><span>${escapeHtml(p.remote ? 'adres' : (p.type || 'locatie'))}${p.price ? ` · vanaf €${p.price}` : ''}</span></button>`).join('');
      box.classList.toggle('open', items.length > 0);
    };
    const render = async (forcePopular=false) => {
      const current = ++requestId;
      const q = input.value.trim();
      let items = q.length >= 2 ? pricing.suggestions(q) : (forcePopular ? popularDefaults() : []);
      draw(dedupePlaces(items));
      if(q.length >= 3){
        const remote = await remoteAddressSuggestions(q);
        if(current !== requestId) return;
        items = dedupePlaces([...items, ...remote]);
        draw(items);
      }
    };
    input.addEventListener('input', ()=> render(true));
    input.addEventListener('focus', ()=> render(true));
    box.addEventListener('click', e=>{
      const btn=e.target.closest('button'); if(!btn) return;
      input.value=btn.dataset.value;
      if(input.id === 'destination'){
        if($('#fixedPrice')) $('#fixedPrice').value = btn.dataset.price || '';
        if(btn.dataset.service && $('#serviceType')) $('#serviceType').value = btn.dataset.service;
      }
      box.classList.remove('open');
      updateEstimate();
      if(input.id === 'calcPickup' || input.id === 'calcDestination') updateCalcEstimate();
      input.dispatchEvent(new Event('change'));
    });
    document.addEventListener('click', e=>{ if(!box.contains(e.target) && e.target !== input) box.classList.remove('open'); });
  }
  function prepareBooking({service='', destination='', price=''}={}){
    const serviceType = $('#serviceType'); if(serviceType && service) serviceType.value = service;
    if(destination && $('#destination')) $('#destination').value = destination;
    if($('#fixedPrice')) $('#fixedPrice').value = price || '';
    const target = $('#boeken'); if(target) target.scrollIntoView({behavior:'smooth', block:'start'});
    setTimeout(()=>{ (destination ? $('#pickup') : $('#destination'))?.focus(); updateEstimate(); }, 250);
  }
  function renderPopularPrices(){
    const grid = $('#popularPriceGrid'); if(!grid || !pricing?.fixedPrices) return;
    const featured = new Set(['Antwerpen centrum','Brussels Airport Zaventem','Charleroi Airport','Schiphol Airport','Antwerpen Airport']);
    grid.innerHTML = pricing.fixedPrices.map(p=>{
      const calculatorOnly = p.calculatorOnly || !p.price;
      const priceLabel = calculatorOnly ? 'Bereken prijs' : `vanaf €${p.price}`;
      const attrs = calculatorOnly
        ? `data-calculator-destination="${escapeHtml(p.name)}" data-service="${p.service || 'standard'}"`
        : `data-fill-destination="${escapeHtml(p.name)}" data-price="${p.price}" data-service="${p.service}"`;
      const badge = p.badge || (calculatorOnly ? 'Calculator' : (p.type === 'luchthaven' ? 'Airport' : (p.km > 95 ? 'Lange afstand' : 'Populair')));
      return `<button type="button" class="price-destination-card ${calculatorOnly ? 'calculator-only' : ''} ${featured.has(p.name) ? 'featured' : ''}" ${attrs}><em>${escapeHtml(badge)}</em><span>${escapeHtml(p.type)}</span><strong>${escapeHtml(p.name)}</strong><b>${priceLabel}</b><small>${escapeHtml(p.note || 'Prijsindicatie')}</small></button>`;
    }).join('');
    const datalist = $('#popularDestinations'); if(datalist) datalist.innerHTML = pricing.allAutocompletePlaces().map(p=>`<option value="${escapeHtml(p.name)}"></option>`).join('');
  }
  function renderLastBooking(b){
    const box = $('#lastBookingWidget'); if(!box) return;
    const url = `tracking.html?code=${encodeURIComponent(b.code)}`;
    box.innerHTML = `<strong>Laatste reservatie</strong><span>Code ${escapeHtml(b.code)} · ${escapeHtml(window.LV.statusLabel(b.status))}</span><a class="btn btn-gold btn-block" href="${url}">Volg uw taxi</a>`;
  }
  function restoreLast(){ try{ const b=JSON.parse(localStorage.getItem('lv_last_booking')||'null'); if(b) renderLastBooking(b); }catch{} }
  async function submit(e){
    e.preventDefault();
    const btn = $('#bookingSubmit'); const result = $('#bookingResult');
    const data = payload();
    btn.disabled = true; btn.textContent = 'Reservatie verzenden...'; result.innerHTML = '';
    try{
      const r = await window.LV_API.createBooking(data);
      const b = r.booking;
      localStorage.setItem('lv_last_booking', JSON.stringify(b)); renderLastBooking(b);
      const url = `${location.origin}/tracking.html?code=${encodeURIComponent(b.code)}`;
      const whatsappText = `Hallo LV Transport, ik heb een reservatie gemaakt. Code: ${b.code}. Rit: ${b.pickup || data.pickup} naar ${b.destination || data.destination}.`;
      result.innerHTML = `<div class="success-card"><span class="eyebrow">Reservatie ontvangen</span><h2>Trackingcode: ${escapeHtml(b.code)}</h2><p>Uw reservatie is verstuurd. U ontvangt een bevestiging per e-mail. Gebruik deze code om uw taxi te volgen.</p><div class="actions-row"><a class="btn btn-gold" href="${url}">Volg uw taxi</a><a class="btn" href="${whatsappUrl(whatsappText)}">WhatsApp met code</a></div><small>${escapeHtml(b.pickup || data.pickup)} → ${escapeHtml(b.destination || data.destination)}</small></div>`;
      notify('Reservatie aangemaakt. Code zichtbaar voor klant.', 'ok');
      setTimeout(()=>{ try{ window.open(whatsappUrl(whatsappText), '_blank'); }catch{} }, 1200);
    } catch(err){ result.innerHTML = `<div class="notice error">Reservatie niet verzonden: ${escapeHtml(err.message || 'API fout')}</div>`; }
    finally { btn.disabled=false; btn.textContent='Reserveer deze rit'; }
  }

  function calcPayload(){ return {
    pickup: $('#calcPickup')?.value.trim() || $('#pickup')?.value.trim(),
    destination: $('#calcDestination')?.value.trim() || $('#destination')?.value.trim(),
    time: $('#time')?.value || '12:00',
    serviceType: $('#serviceType')?.value || 'standard',
    fixedPrice: ''
  }; }
  async function updateCalcEstimate(){
    const data = calcPayload();
    if(!data.pickup || !data.destination){
      if($('#smartPriceResult')) $('#smartPriceResult').innerHTML = '<strong>Adres A + B</strong><span>Vul vertrek en bestemming in.</span>';
      return;
    }
    const est = await pricing.estimateSmart(data);
    const html = `<div class="price-main"><span>Richtprijs</span><strong>${niceMoney(est.low)} – ${niceMoney(est.high)}</strong></div><div class="price-sub">${est.distanceKm} km · ±${est.minutes} min · ${est.tariff}</div><small>Prijsindicatie op basis van vertrek en bestemming. LV Transport controleert uitzonderlijke ritten.</small>`;
    if($('#smartPriceResult')) $('#smartPriceResult').innerHTML = html;
  }
  function copyCalcToBooking(){
    const pu = $('#calcPickup')?.value.trim();
    const de = $('#calcDestination')?.value.trim();
    if(pu && $('#pickup')) $('#pickup').value = pu;
    if(de && $('#destination')) $('#destination').value = de;
    if($('#fixedPrice')) $('#fixedPrice').value = '';
    updateEstimate();
    $('#boeken')?.scrollIntoView({behavior:'smooth', block:'start'});
  }


  async function applySiteConfig(){
    let cfg = null;
    try{ cfg = await window.LV_API.publicSiteConfig(); }catch{}
    if(!cfg){ try{ cfg = JSON.parse(localStorage.getItem('lv_site_config') || 'null'); }catch{} }
    if(!cfg) return;
    if(cfg.heroTitle) document.querySelectorAll('[data-site-text="heroTitle"]').forEach(el=> el.textContent = cfg.heroTitle);
    if(cfg.heroSubtitle) document.querySelectorAll('[data-site-text="heroSubtitle"]').forEach(el=> el.innerHTML = escapeHtml(cfg.heroSubtitle).replace(/\.\s+/g,'.<br>'));
    if(Array.isArray(cfg.prices) && window.LV_CONFIG?.POPULAR_PRICES){
      cfg.prices.forEach(p=>{ const target = window.LV_CONFIG.POPULAR_PRICES.find(x=>x.name===p.name); if(target && !target.calculatorOnly && p.price) target.price = Number(p.price); });
      renderPopularPrices();
    }
  }
  const defaultReviews = [
    {name:'Klant luchthavenrit', stars:5, text:'Stipt, discreet en heel comfortabel naar Zaventem.'},
    {name:'Zakelijke klant', stars:5, text:'Professionele service en duidelijke communicatie.'},
    {name:'LV VIP klant', stars:5, text:'Makkelijk boeken en direct een code om de rit te volgen.'}
  ];
  function getReviews(){ try{ return JSON.parse(localStorage.getItem('lv_reviews') || 'null') || defaultReviews; }catch{ return defaultReviews; } }
  function saveReviews(list){ localStorage.setItem('lv_reviews', JSON.stringify(list.slice(0,12))); }
  function renderReviews(){
    const box = $('#reviewsList'); if(!box) return;
    const list = getReviews();
    box.innerHTML = list.slice(0,5).map(r=>`<div class="review-item"><div class="review-stars">${'★'.repeat(Number(r.stars||5))}${'☆'.repeat(5-Number(r.stars||5))}</div><strong>${escapeHtml(r.name||'Klant')}</strong><p>${escapeHtml(r.text||'Bedankt voor uw beoordeling.')}</p></div>`).join('');
  }
  function setupReviews(){
    let selected = 5;
    const stars = $('#reviewStars');
    function paint(){ stars?.querySelectorAll('button').forEach(btn=>btn.classList.toggle('active', Number(btn.dataset.star)<=selected)); }
    stars?.addEventListener('click', e=>{ const btn=e.target.closest('button'); if(!btn) return; selected=Number(btn.dataset.star); paint(); });
    $('#reviewForm')?.addEventListener('submit', e=>{
      e.preventDefault();
      const item = { name: $('#reviewName')?.value.trim() || 'LV Transport klant', code: $('#reviewCode')?.value.trim(), stars:selected, text: $('#reviewText')?.value.trim() || 'Prima service.' };
      const list = [item, ...getReviews()]; saveReviews(list); renderReviews(); e.currentTarget.reset(); selected=5; paint(); notify('Bedankt voor uw review.', 'ok');
    });
    paint(); renderReviews();
  }

  document.addEventListener('DOMContentLoaded',()=>{
    restoreLast(); renderPopularPrices(); applySiteConfig(); setupReviews();
    ['pickup','destination','calcPickup','calcDestination'].forEach(id=>{ const input=$(`#${id}`); if(input) attachSuggestions(input); });
    ['pickup','destination','date','time','serviceType','fixedPrice'].forEach(id=>{ const el=$(`#${id}`); if(el) ['input','change'].forEach(ev=>el.addEventListener(ev, updateEstimate)); });
    ['calcPickup','calcDestination'].forEach(id=>{ const el=$(`#${id}`); if(el) ['input','change'].forEach(ev=>el.addEventListener(ev, updateCalcEstimate)); });
    $('#quickCalcForm')?.addEventListener('submit', e=>{ e.preventDefault(); updateCalcEstimate(); });
    $('#calcToBooking')?.addEventListener('click', copyCalcToBooking);
    $all('[data-service]').forEach(el=> el.addEventListener('click',()=>{
      const scrollTarget = el.dataset.scroll;
      if(scrollTarget && scrollTarget !== '#boeken') { const t = $(scrollTarget); if(t) t.scrollIntoView({behavior:'smooth', block:'start'}); }
      if(scrollTarget === '#boeken' || el.dataset.destination || el.dataset.fixedPrice) prepareBooking({service:el.dataset.service, destination:el.dataset.destination || '', price:el.dataset.fixedPrice || el.dataset.price || ''});
    }));
    $all('[data-fill-destination]').forEach(el=> el.addEventListener('click',()=> prepareBooking({destination:el.dataset.fillDestination, price:el.dataset.price || '', service:el.dataset.service || 'standard'})));
    $all('[data-calc-destination]').forEach(el=> el.addEventListener('click',()=>{ if($('#calcDestination')) $('#calcDestination').value = el.dataset.calcDestination || ''; updateCalcEstimate(); $('#calcPickup')?.focus(); }));
    $all('[data-calculator-destination]').forEach(el=> el.addEventListener('click',()=>{
      if($('#calcDestination')) $('#calcDestination').value = el.dataset.calculatorDestination || '';
      if($('#destination')) $('#destination').value = el.dataset.calculatorDestination || '';
      if($('#fixedPrice')) $('#fixedPrice').value = '';
      if($('#serviceType')) $('#serviceType').value = el.dataset.service || 'standard';
      $('#calculator')?.scrollIntoView({behavior:'smooth', block:'start'});
      setTimeout(()=>{ $('#calcPickup')?.focus(); updateCalcEstimate(); updateEstimate(); }, 250);
    }));
    $('#bookingForm')?.addEventListener('submit', submit);
    document.querySelector('[data-quick-track]')?.addEventListener('submit', e=>{
      e.preventDefault();
      const code = e.currentTarget.querySelector('input')?.value.trim();
      if(code) location.href = `tracking.html?code=${encodeURIComponent(code)}`;
    });
    $('#menuToggle')?.addEventListener('click',()=>{ const menu=$('#mobileMenu'); const btn=$('#menuToggle'); const open=!menu.classList.contains('open'); menu.classList.toggle('open', open); btn.setAttribute('aria-expanded', String(open)); });
    $('#mobileMenu')?.addEventListener('click', e=>{ if(e.target.matches('a')) { $('#mobileMenu').classList.remove('open'); $('#menuToggle')?.setAttribute('aria-expanded','false'); } });
    updateEstimate();
  });
  window.LV_BOOKING = { prepareBooking, updateEstimate, updateCalcEstimate, copyCalcToBooking };
})();
