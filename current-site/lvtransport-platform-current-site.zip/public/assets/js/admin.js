(function(){
  const { $, escapeHtml, statusLabel, money, notify } = window.LV || {};
  let token = window.LV_API?.getToken('admin') || '';
  let drivers = [];
  async function login(){
    try{ const r = await window.LV_API.login('admin', $('#loginEmail').value.trim(), $('#loginPassword').value); token=r.token; showApp(); load(); }
    catch(e){ $('#loginMsg').textContent = 'Login mislukt: ' + e.message; }
  }
  function showApp(){ $('#loginPanel')?.classList.add('hidden'); $('#adminApp')?.classList.remove('hidden'); }
  function metric(label, value, note=''){ return `<div class="stat"><strong>${escapeHtml(value)}</strong><span>${escapeHtml(label)}</span>${note?`<small>${escapeHtml(note)}</small>`:''}</div>`; }
  function renderStats(d){ $('#statsGrid').innerHTML = [metric('Actieve ritten', d.active||0), metric('Pending', d.pending||0), metric('Vandaag', d.today||0), metric('Omzet indicatie', money(d.estimatedRevenue||0))].join(''); }
  function bookingCard(b){
    const driverOptions = drivers.map(d=>`<option value="${escapeHtml(d.id)}" ${b.driverId===d.id?'selected':''}>${escapeHtml(d.name)} · ${escapeHtml(d.status||'offline')}</option>`).join('');
    return `<article class="booking-card"><div class="booking-top"><div><span class="status ${b.status}">${statusLabel(b.status)}</span><h3>Code ${escapeHtml(b.code)}</h3></div><strong>${money(b.priceEstimate?.low||b.priceEstimate?.exact||0)}–${money(b.priceEstimate?.high||b.priceEstimate?.exact||0)}</strong></div><div class="route-mini"><span>📍 ${escapeHtml(b.pickup)}</span><span>→</span><span>🏁 ${escapeHtml(b.destination)}</span></div><div class="booking-meta"><span>${escapeHtml(b.name||'')}</span><span>${escapeHtml(b.phone||'')}</span><span>${escapeHtml(b.date||'')} ${escapeHtml(b.time||'')}</span><span>${b.priceEstimate?.distanceKm||'?'} km</span></div><div class="admin-supervision"><select data-driver="${b.id}"><option value="">Chauffeur kiezen</option>${driverOptions}</select><button class="btn btn-small" data-assign="${b.id}">Toewijzen</button><button class="btn btn-small" data-status="accepted" data-id="${b.id}">Accepteren</button><button class="btn btn-small" data-status="cancelled" data-id="${b.id}">Annuleren</button><a class="btn btn-small" href="tracking.html?code=${escapeHtml(b.code)}">Tracking</a></div></article>`;
  }
  function renderDrivers(list){ $('#driversList').innerHTML = list.map(d=>`<div class="driver-item"><strong>${escapeHtml(d.name)}</strong><span class="pill ${['available','busy'].includes(d.status)?'ok':''}">${escapeHtml(d.status||'offline')}</span><p class="muted">${escapeHtml(d.vehicle||'LV Transport')}</p></div>`).join('') || '<div class="empty-state">Geen chauffeurs</div>'; }
  function renderAlerts(bookings){
    const alerts=[]; const now=Date.now();
    bookings.filter(b=>b.status==='pending').forEach(b=>alerts.push({type:'pending',text:`Reservatie ${b.code} wacht op chauffeur`}));
    bookings.filter(b=>b.status==='driver_on_route' && !b.driverLocation).forEach(b=>alerts.push({type:'gps',text:`Rit ${b.code}: GPS nog niet zichtbaar`}));
    $('#alertsList').innerHTML = alerts.length ? alerts.slice(0,8).map(a=>`<div class="audit-item"><strong>${escapeHtml(a.text)}</strong><span>${escapeHtml(a.type)}</span></div>`).join('') : '<div class="empty-state">Geen kritieke alerts</div>';
  }
  function renderCustomers(customers){
    $('#customersList').innerHTML = (customers||[]).slice(0,8).map(c=>`<div class="driver-item"><strong>${escapeHtml(c.name||'Klant')}</strong><span class="pill">${c.rides||0} ritten</span><p class="muted">${escapeHtml(c.email||c.phone||'')}</p></div>`).join('') || '<div class="empty-state">Nog geen klantenhistoriek</div>';
  }
  function renderAudit(audit){ $('#auditList').innerHTML = (audit||[]).slice(0,10).map(a=>`<div class="audit-item"><strong>${escapeHtml(a.action)}</strong><span>${escapeHtml(a.actor||'system')} · ${new Date(a.at).toLocaleString('nl-BE')}</span></div>`).join('') || '<div class="empty-state">Geen auditlog</div>'; }

  function defaultSiteConfig(){
    return {
      heroTitle: 'Antwerpen 24/7 service',
      heroSubtitle: 'Uw rit in Antwerpen en heel België, verzorgd met discretie, klasse en professionaliteit. Ontvang uw code en volg uw rit online.',
      prices: (window.LV_CONFIG?.POPULAR_PRICES || []).map(p=>({ name:p.name, price:p.price, calculatorOnly:!!p.calculatorOnly }))
    };
  }
  function loadLocalSiteConfig(){
    try{ return JSON.parse(localStorage.getItem('lv_site_config') || 'null') || defaultSiteConfig(); }catch{ return defaultSiteConfig(); }
  }
  function renderSiteControl(){
    const cfg = loadLocalSiteConfig();
    const t = $('#siteHeroTitle'), s = $('#siteHeroSubtitle');
    if(t) t.value = cfg.heroTitle || '';
    if(s) s.value = cfg.heroSubtitle || '';
    const list = $('#sitePricesEditor'); if(!list) return;
    list.innerHTML = (cfg.prices || []).map((p,i)=>`<div class="site-price-row"><strong>${escapeHtml(p.name)}</strong>${p.calculatorOnly ? '<span class="pill">Bereken prijs</span>' : `<label>vanaf €<input data-site-price="${i}" type="number" min="0" step="1" value="${Number(p.price || 0)}"></label>`}</div>`).join('');
  }
  function collectSiteConfig(){
    const cfg = loadLocalSiteConfig();
    cfg.heroTitle = $('#siteHeroTitle')?.value.trim() || cfg.heroTitle;
    cfg.heroSubtitle = $('#siteHeroSubtitle')?.value.trim() || cfg.heroSubtitle;
    document.querySelectorAll('[data-site-price]').forEach(input=>{ const i=Number(input.dataset.sitePrice); if(cfg.prices && cfg.prices[i]) cfg.prices[i].price = Number(input.value || 0); });
    return cfg;
  }
  function saveLocalSiteConfig(){
    const cfg = collectSiteConfig();
    localStorage.setItem('lv_site_config', JSON.stringify(cfg));
    $('#siteControlMsg').textContent = 'Preview opgeslagen in deze browser. Open Website om de lokale preview te zien. Voor alle bezoekers moet de API-publicatie actief zijn.';
  }
  async function publishSiteConfig(){
    try{
      const cfg = collectSiteConfig();
      const res = await window.LV_API.adminSaveSiteConfig(token, cfg);
      $('#siteControlMsg').textContent = 'Gepubliceerd via API: ' + JSON.stringify(res, null, 2);
    }catch(e){
      $('#siteControlMsg').textContent = 'API-publicatie nog niet actief: ' + e.message + '\nLokale preview blijft beschikbaar. Backend-endpoint /api/admin/site-config moet nog worden toegevoegd voor globale publicatie.';
    }
  }
  function exportSiteConfig(){
    const cfg = collectSiteConfig();
    const blob = new Blob([JSON.stringify(cfg,null,2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download='lvtransport-site-config.json'; a.click();
    URL.revokeObjectURL(url);
  }

  async function load(){
    try{ const r=await window.LV_API.adminDashboard(token); drivers=r.drivers||[]; renderStats(r.dashboard||{}); renderDrivers(drivers); renderAlerts(r.bookings||[]); renderCustomers(r.customers||[]); renderAudit(r.audit||[]); $('#bookingsList').innerHTML = (r.bookings||[]).slice(0,80).map(bookingCard).join('') || '<div class="empty-state">Geen reservaties</div>'; $('#exportBtn').href = `${window.LV_API.base}/api/admin/export/bookings.csv?token=${encodeURIComponent(token)}`; }
    catch(e){ notify(e.message,'error'); if(e.status===401){ window.LV_API.clearToken('admin'); location.reload(); } }
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('#loginBtn')?.addEventListener('click', login); $('#refreshBtn')?.addEventListener('click', load); if(token){ showApp(); load(); }
    $('#siteControlBtn')?.addEventListener('click', ()=>{ $('#siteControlPanel')?.classList.remove('hidden'); renderSiteControl(); $('#siteControlPanel')?.scrollIntoView({behavior:'smooth', block:'start'}); });
    $('#closeSiteControl')?.addEventListener('click', ()=> $('#siteControlPanel')?.classList.add('hidden'));
    $('#saveSiteConfig')?.addEventListener('click', saveLocalSiteConfig);
    $('#publishSiteConfig')?.addEventListener('click', publishSiteConfig);
    $('#exportSiteConfig')?.addEventListener('click', exportSiteConfig);
    $('#bookingsList')?.addEventListener('click', async e=>{
      const id=e.target.dataset.id, status=e.target.dataset.status, assign=e.target.dataset.assign;
      try{ if(status) await window.LV_API.adminStatus(token,id,status); if(assign){ const sel=document.querySelector(`select[data-driver="${assign}"]`); if(!sel.value) return notify('Kies eerst chauffeur','error'); await window.LV_API.adminAssign(token,assign,sel.value); } await load(); }catch(err){ notify(err.message,'error'); }
    });
    setInterval(load, 10000);
  });
})();
