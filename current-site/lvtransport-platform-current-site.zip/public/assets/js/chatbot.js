(function(){
  const { $, escapeHtml, whatsappUrl } = window.LV || {};
  const pricing = window.LV_PRICING;
  const cfg = window.LV_CONFIG || {};
  async function askAssistantAPI(message){
    const url = cfg.ASSISTANT_API_URL || (cfg.API_BASE_URL ? `${cfg.API_BASE_URL}/api/assistant` : '');
    if(!url) return null;
    try{
      const ctrl = new AbortController();
      const timer = setTimeout(()=>ctrl.abort(), 4500);
      const res = await fetch(url, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        signal: ctrl.signal,
        body: JSON.stringify({
          message,
          assistant:'Moni Assistent',
          brand:'LV Transport',
          language: lang(message),
          context:{ page:'client', services:['taxi','luchthavenvervoer','zakelijk vervoer','tracking','LV VIP'], publicOnly:true }
        })
      });
      clearTimeout(timer);
      if(!res.ok) return null;
      const data = await res.json();
      if(!data || !data.reply) return null;
      return { text: data.reply, action: data.action || null };
    }catch{ return null; }
  }

  function addMsg(text, cls='bot'){
    const log = $('#chatLog'); if(!log) return;
    const div = document.createElement('div'); div.className=`chat-msg ${cls}`; div.innerHTML = text;
    log.appendChild(div); log.scrollTop = log.scrollHeight;
  }
  function norm(s=''){
    return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s-]/g,' ').replace(/\s+/g,' ').trim();
  }
  function has(msg, words){ const m=norm(msg); return words.some(w => m.includes(norm(w))); }
  function lang(msg){
    const m = norm(msg);
    if(/\b(quiero|precio|cuanto|cuánto|reserva|taxi|aeropuerto|factura|seguir|codigo|código|ayuda|hola|gracias|viaje)\b/.test(m)) return 'es';
    if(/\b(price|book|booking|track|airport|invoice|hello|help|ride|cost|fare)\b/.test(m)) return 'en';
    return 'nl';
  }
  function detectPlace(msg){ return pricing?.bestPlace(msg) || null; }
  function fixedFor(msg){ return pricing?.fixedPriceFor(msg) || null; }
  function close(){ $('#chatPanel')?.classList.remove('open'); }
  function open(){ $('#chatPanel')?.classList.add('open'); setTimeout(()=>$('#chatInput')?.focus(),120); }
  function minimizeAfterGuiding(){ setTimeout(()=>close(), 750); }
  function goBooking({pickup='', destination='', service='standard', price=''}={}){
    window.LV_BOOKING?.prepareBooking({service, destination, price});
    minimizeAfterGuiding();
  }
  function actionButton(label, attrs={}){
    const data = Object.entries(attrs).map(([k,v])=>`data-${k}="${escapeHtml(v)}"`).join(' ');
    return `<br><br><button class="btn btn-gold btn-small moni-action" ${data}>${escapeHtml(label)}</button>`;
  }
  function priceText(place, l='nl'){
    if(!place) return '';
    const fixed = fixedFor(place.name) || place;
    if(fixed?.price){
      if(l==='es') return `Para <strong>${escapeHtml(fixed.name)}</strong> la indicación es <strong>desde €${fixed.price}</strong>. Es una estimación; LV Transport puede revisar el precio final si hay espera, parking o servicios especiales.`;
      if(l==='en') return `For <strong>${escapeHtml(fixed.name)}</strong>, the indicative price starts at <strong>€${fixed.price}</strong>. It remains an estimate; LV Transport may adjust for waiting time, parking or special service.`;
      return `Voor <strong>${escapeHtml(fixed.name)}</strong> is de richtprijs <strong>vanaf €${fixed.price}</strong>. Dit blijft een indicatie; wachttijd, parking of speciale service kan worden aangepast.`;
    }
    if(place){
      if(l==='es') return `Para <strong>${escapeHtml(place.name)}</strong> usamos la calculadora inteligente, porque el precio depende de la dirección exacta, hora y tráfico. LV Transport confirma la indicación final cuando sea necesario.`;
      if(l==='en') return `For <strong>${escapeHtml(place.name)}</strong> we use the smart calculator because the price depends on the exact address, time and traffic. LV Transport can confirm the final estimate when needed.`;
      return `Voor <strong>${escapeHtml(place.name)}</strong> gebruiken we de slimme calculator, omdat de prijs afhangt van exact adres, uur en verkeer. LV Transport kan de indicatie bevestigen indien nodig.`;
    }
    return '';
  }
  function bookingAction(destination='', service='standard', price=''){
    return actionButton('Vul formulier in', { 'moni-fill':'1', destination, service, price });
  }
  function trackingLink(code){ return `<a href="tracking.html?code=${encodeURIComponent(code)}">Volg uw taxi</a>`; }

  function replyNL(msg){
    const place = detectPlace(msg); const fixed = fixedFor(place?.name || msg); const code = (msg.match(/\b\d{6}\b/)||[])[0];
    if(has(msg,['tracking','volg','code','reservatiecode','waar is','taxi volgen'])){
      if(code) return { text:`Natuurlijk. U kunt uw rit hier volgen: ${trackingLink(code)}.`, action:null };
      return { text:'Natuurlijk. Ga naar “Taxi tracking” en voer uw 6-cijferige reservatiecode in. Die code staat op het scherm na reservatie en in uw bevestigingsmail.', action:'tracking' };
    }
    if(has(msg,['prijs','tarief','kost','kostprijs','bereken','hoeveel','zaventem','charleroi','schiphol','eindhoven','blankenberge','airport','luchthaven'])){
      if(place){
        const service = place.type === 'luchthaven' ? 'airport' : (fixed?.service || 'long_distance');
        return { text:`${priceText(place,'nl')} Wilt u dat ik de reservatie alvast voorbereid?${bookingAction(place.name, service, fixed?.price || '')}`, action:null };
      }
      return { text:'Graag. Geef vertrekplaats en bestemming, dan toon ik een realistische prijsindicatie. U kunt ook “Prijzen” openen voor populaire routes.', action:'calculator' };
    }
    if(has(msg,['reserveer','boeken','boek','rit','taxi nodig','taxi bestellen'])){
      return { text:'Zeker, met plezier. Ik breng u meteen naar het reservatieformulier. Vul uw naam, telefoon, ophaaladres, bestemming, datum en uur in. Daarna ontvangt u direct uw trackingcode op het scherm en per e-mail.', action:'booking' };
    }
    if(has(msg,['vip','abonnement','maandelijks','business','zakelijk','bedrijf','factuur','klantenvoordeel'])){
      return { text:'Voor zakelijke klanten, LV VIP, rittenbundels en facturatie help ik u graag. Ik breng u naar de zone “Zakelijke klanten & LV VIP”, waar u een businessrit of VIP-plan kunt aanvragen.', action:'vip' };
    }
    if(has(msg,['whatsapp','mens','operator','persoon','support','contact'])){
      return { text:`Natuurlijk. U kunt ons ook rechtstreeks via WhatsApp bereiken: <a href="${whatsappUrl('Hallo LV Transport, ik heb een vraag.')}">Open WhatsApp</a>.`, action:null };
    }
    return { text:'Ik help u graag. Wilt u een rit reserveren, een prijs berekenen, een taxi volgen of informatie over luchthavenvervoer / LV VIP?', action:null };
  }
  function replyES(msg){
    const place = detectPlace(msg); const fixed = fixedFor(place?.name || msg); const code = (msg.match(/\b\d{6}\b/)||[])[0];
    if(has(msg,['tracking','seguir','codigo','código','taxi'])){
      if(code) return { text:`Claro. Puede seguir su viaje aquí: ${trackingLink(code)}.`, action:null };
      return { text:'Claro. Entre en “Taxi tracking” y escriba su código de 6 números. El código aparece después de reservar y también llega por email.', action:'tracking' };
    }
    if(has(msg,['precio','cuanto','cuánto','cuesta','tarifa','zaventem','charleroi','aeropuerto','blankenberge','blanckenberge','blankenbergen'])){
      if(place){
        const service = place.type === 'luchthaven' ? 'airport' : (fixed?.service || 'long_distance');
        return { text:`${priceText(place,'es')} ¿Quiere que le prepare el formulario con ese destino?${bookingAction(place.name, service, fixed?.price || '')}`, action:null };
      }
      return { text:'Con gusto. Escriba origen y destino para darle una indicación realista. También puede tocar “Prijzen” para ver destinos populares.', action:'calculator' };
    }
    if(has(msg,['reservar','reserva','quiero un taxi','taxi','viaje'])){
      return { text:'Claro, con mucho gusto. Le llevo directamente al formulario de reserva. Complete sus datos, origen, destino, fecha y hora. Al enviar recibirá el código de seguimiento en pantalla y por email.', action:'booking' };
    }
    if(has(msg,['factura','empresa','vip','abono','mensual','business','cliente frecuente'])){
      return { text:'Sí, para factura, clientes frecuentes, planes VIP o business puede usar la sección “Zakelijke klanten & LV VIP”. Le llevo ahí.', action:'vip' };
    }
    return { text:'Con gusto. Le ayudo con reserva, precio, tracking, aeropuerto, LV VIP o soporte. ¿Qué necesita?', action:null };
  }
  function replyEN(msg){
    const place = detectPlace(msg); const fixed = fixedFor(place?.name || msg); const code=(msg.match(/\b\d{6}\b/)||[])[0];
    if(has(msg,['track','tracking','code'])) return { text: code ? `You can track your ride here: ${trackingLink(code)}.` : 'Please open Taxi tracking and enter your 6-digit reservation code.', action: code ? null : 'tracking' };
    if(has(msg,['price','cost','fare','airport','booking','book'])){
      if(place){ const service = place.type === 'luchthaven' ? 'airport' : (fixed?.service || 'long_distance'); return { text:`${priceText(place,'en')} Shall I prepare the booking form?${bookingAction(place.name, service, fixed?.price || '')}`, action:null }; }
      return { text:'I can help with a realistic price estimate. Please provide pickup and destination, or open Prices for popular routes.', action:'calculator' };
    }
    return { text:'Of course. I can help with booking, price estimate, airport transfer, tracking, VIP or business rides. What do you need?', action:null };
  }
  function answer(msg){ const l=lang(msg); return l==='es' ? replyES(msg) : l==='en' ? replyEN(msg) : replyNL(msg); }
  function executeAction(action){
    if(action === 'booking') { setTimeout(()=>{ $('#boeken')?.scrollIntoView({behavior:'smooth', block:'start'}); $('#pickup')?.focus(); minimizeAfterGuiding(); }, 600); }
    if(action === 'calculator') { setTimeout(()=>{ $('#calculator')?.scrollIntoView({behavior:'smooth', block:'start'}); minimizeAfterGuiding(); }, 700); }
    if(action === 'tracking') { setTimeout(()=>{ location.href='tracking.html'; }, 700); }
    if(action === 'vip') { setTimeout(()=>{ $('#vip')?.scrollIntoView({behavior:'smooth', block:'start'}); minimizeAfterGuiding(); }, 700); }
  }
  async function send(){
    const input=$('#chatInput'); const msg=input?.value.trim(); if(!msg) return;
    input.value=''; addMsg(escapeHtml(msg),'user');
    addMsg('Een moment, ik kijk het voor u na...','bot');
    const remote = await askAssistantAPI(msg);
    const log = $('#chatLog');
    const pending = log?.querySelector('.chat-msg.bot:last-child');
    if(pending && pending.textContent.includes('Een moment')) pending.remove();
    const r = remote || answer(msg);
    addMsg(r.text,'bot'); executeAction(r.action);
  }

  function setupDraggableChat(){
    const toggle = $('#chatToggle');
    const panel = $('#chatPanel');
    if(!toggle || !panel) return;
    const saved = (()=>{ try{return JSON.parse(localStorage.getItem('lv_chat_position')||'null')}catch{return null} })();
    function apply(pos){
      if(!pos) return;
      const maxX = Math.max(8, window.innerWidth - toggle.offsetWidth - 8);
      const maxY = Math.max(8, window.innerHeight - toggle.offsetHeight - 8);
      const x = Math.min(Math.max(8, pos.x), maxX);
      const y = Math.min(Math.max(8, pos.y), maxY);
      toggle.style.left = x + 'px'; toggle.style.top = y + 'px'; toggle.style.right = 'auto'; toggle.style.bottom = 'auto';
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
      panel.style.left = Math.min(Math.max(8, x - Math.max(0, panel.offsetWidth - toggle.offsetWidth)), Math.max(8, window.innerWidth - panel.offsetWidth - 8)) + 'px';
      panel.style.top = Math.max(8, y - panel.offsetHeight - 10) + 'px';
      localStorage.setItem('lv_chat_position', JSON.stringify({x,y}));
    }
    if(saved) setTimeout(()=>apply(saved), 50);
    let dragging=false, moved=false, dx=0, dy=0;
    toggle.addEventListener('pointerdown', e=>{ dragging=true; moved=false; dx=e.clientX-toggle.getBoundingClientRect().left; dy=e.clientY-toggle.getBoundingClientRect().top; toggle.setPointerCapture?.(e.pointerId); toggle.classList.add('dragging'); });
    toggle.addEventListener('pointermove', e=>{ if(!dragging) return; moved=true; apply({x:e.clientX-dx, y:e.clientY-dy}); });
    toggle.addEventListener('pointerup', e=>{ if(!dragging) return; dragging=false; toggle.classList.remove('dragging'); if(moved){ e.preventDefault(); e.stopPropagation(); setTimeout(()=>toggle.dataset.justDragged='0',150); toggle.dataset.justDragged='1'; } });
    window.addEventListener('resize', ()=>{ try{ apply(JSON.parse(localStorage.getItem('lv_chat_position')||'null')); }catch{} });
  }

  document.addEventListener('DOMContentLoaded',()=>{
    setupDraggableChat();
    $('#chatToggle')?.addEventListener('click',()=>{ const panel=$('#chatPanel'); panel?.classList.contains('open') ? close() : open(); });
    $('#chatClose')?.addEventListener('click',close);
    $('#chatSend')?.addEventListener('click', send);
    $('#chatInput')?.addEventListener('keydown', e=>{ if(e.key==='Enter') send(); });
    $('#chatLog')?.addEventListener('click', e=>{
      const quick = e.target.closest('[data-quick]');
      if(quick){ $('#chatInput').value=quick.dataset.quick; send(); return; }
      const btn=e.target.closest('[data-moni-fill]'); if(!btn) return;
      goBooking({ destination: btn.dataset.destination || '', service: btn.dataset.service || 'standard', price: btn.dataset.price || '' });
    });
    document.addEventListener('keydown', e=>{ if(e.key==='Escape') close(); });
  });
})();
