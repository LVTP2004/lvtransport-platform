(function(){
  const cfg = window.LV_CONFIG || {};
  function $(sel, root=document){ return root.querySelector(sel); }
  function $all(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function escapeHtml(s=''){ return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }
  function statusLabel(status){ return ({pending:'In behandeling',accepted:'Geaccepteerd',driver_assigned:'Chauffeur toegewezen',driver_on_route:'Chauffeur onderweg',arrived:'Chauffeur aangekomen',in_progress:'Rit gestart',completed:'Rit voltooid',cancelled:'Geannuleerd',rejected:'Geweigerd'})[status] || status || 'Onbekend'; }
  function money(v){ const n = Number(v || 0); return `€${n.toFixed(0)}`; }
  function whatsappUrl(text=''){ const number = cfg.WHATSAPP_NUMBER || ''; return `https://wa.me/${number}?text=${encodeURIComponent(text || 'Hallo LV Transport, ik wil graag een rit reserveren.')}`; }
  function updateApiState(){ const el = $('#apiState'); if(!el || !window.LV_API) return; window.LV_API.health().then(()=>{el.textContent='API online'; el.className='pill ok';}).catch(()=>{el.textContent='API offline'; el.className='pill error';}); }
  function notify(msg, type='ok'){ let box = $('#toastBox'); if(!box){ box=document.createElement('div'); box.id='toastBox'; box.className='toast-box'; document.body.appendChild(box); } const item=document.createElement('div'); item.className=`toast ${type}`; item.textContent=msg; box.appendChild(item); setTimeout(()=>item.remove(),4200); }
  function setTodayDefaults(){ const d=$('#date'), t=$('#time'); const now=new Date(); if(d && !d.value) d.value = now.toISOString().slice(0,10); if(t && !t.value){ now.setMinutes(now.getMinutes()+30); t.value = now.toTimeString().slice(0,5); } }
  document.addEventListener('DOMContentLoaded',()=>{
    updateApiState(); setTodayDefaults();
    $all('[data-whatsapp]').forEach(a=>{ a.href = whatsappUrl(); a.addEventListener('click', e=>{ if(a.tagName === 'BUTTON'){ e.preventDefault(); location.href=whatsappUrl(); } }); });
    $all('[data-mailto]').forEach(a=>{ a.href = `mailto:${cfg.PUBLIC_EMAIL || 'info@lvtransport.be'}`; });
    $all('[data-scroll]').forEach(el=> el.addEventListener('click',()=>{ const target=$(el.dataset.scroll); if(target) target.scrollIntoView({behavior:'smooth', block:'start'}); }));
  });
  window.LV = { $, $all, escapeHtml, statusLabel, money, whatsappUrl, notify, updateApiState, setTodayDefaults };
})();
