(function(){
  const cfg = window.LV_CONFIG || {};
  const places = cfg.COMMON_PLACES || [];
  const fixedPrices = cfg.POPULAR_PRICES || [];
  function normalize(s=''){
    return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9\s-]/g,' ').replace(/\s+/g,' ').trim();
  }
  function namesFor(p){ return [p.name, p.type, p.note, ...(p.aliases || [])].filter(Boolean); }
  function scoreText(query, text){
    const q = normalize(query), x = normalize(text);
    if(!q || !x) return 0;
    if(x === q) return 100;
    if(x.startsWith(q)) return 92;
    if(x.includes(q)) return 82;
    const qParts = q.split(' ').filter(v=>v.length>1);
    if(qParts.some(part => x.startsWith(part))) return 70;
    if(qParts.some(part => part.length > 2 && x.includes(part))) return 62;
    if(q.length >= 4 && x.slice(0, Math.min(6, x.length, q.length)) === q.slice(0, Math.min(6, x.length, q.length))) return 55;
    return 0;
  }
  function scorePlace(query, p){ return Math.max(0, ...namesFor(p).map(n => scoreText(query, n))); }
  function allAutocompletePlaces(){
    const map = new Map();
    [...places, ...fixedPrices].forEach(p => { if(p.name && !map.has(p.name)) map.set(p.name, p); });
    return Array.from(map.values());
  }
  function suggestions(query){
    if(!normalize(query) || normalize(query).length < 2) return [];
    return allAutocompletePlaces().map(p => ({...p, _score: scorePlace(query,p)})).filter(p => p._score > 0).sort((a,b)=> b._score-a._score || a.name.localeCompare(b.name)).slice(0,10);
  }
  function bestPlace(text){
    const ranked = allAutocompletePlaces().map(p => ({p, score: scorePlace(text,p)})).sort((a,b)=> b.score-a.score);
    return ranked[0] && ranked[0].score > 0 ? ranked[0].p : null;
  }
  function fixedPriceFor(text){
    const ranked = fixedPrices.map(p => ({p, score: scorePlace(text,p)})).sort((a,b)=> b.score-a.score);
    return ranked[0] && ranked[0].score >= 55 ? ranked[0].p : null;
  }
  function isNight(time=''){
    const [h=12,m=0] = String(time || '12:00').split(':').map(Number);
    const minutes = (Number(h)||12)*60 + (Number(m)||0);
    return minutes >= 1320 || minutes < 360;
  }
  function hasAirport(text){ return /airport|luchthaven|zaventem|charleroi|schiphol|eindhoven|aeropuerto/i.test(text || ''); }
  function taximeterEstimate(km, night=false){
    const p = cfg.PRICE || {};
    const start = Number(p.startFee || 4.9);
    const first = Number(p.firstKmRate || 2.5);
    const after = Number(p.afterKmRate || 2.3);
    const switchKm = Number(p.kmSwitch || 5);
    const base = km <= switchKm ? start + km * first : start + switchKm * first + (km - switchKm) * after;
    const withNight = base + (night ? Number(p.nightFee || 2.5) : 0);
    return Math.max(Number(p.minimum || 12), withNight);
  }
  function estimate(payload={}){
    const p = cfg.PRICE || {};
    const dest = fixedPriceFor(payload.destination) || bestPlace(payload.destination);
    const pickup = bestPlace(payload.pickup);
    const night = isNight(payload.time);
    let km = Number(dest?.km || pickup?.km || 8);
    let service = payload.serviceType || dest?.service || 'standard';
    const manuallyFixed = Number(payload.fixedPrice || payload.price || 0);
    let exact = manuallyFixed || Number(dest?.price || 0);
    let fixed = Boolean(exact);
    if(!exact){
      exact = taximeterEstimate(km, night);
      if(km > 25) exact = Math.max(exact, taximeterEstimate(km, night) * 1.02);
      if(hasAirport(`${payload.destination || ''} ${payload.pickup || ''}`) && service !== 'airport') service = 'airport';
    }
    if(service === 'airport' && /zaventem|brussels airport/i.test(payload.destination || '') && !fixed){ exact = Number(p.airportZaventem || 88); fixed = true; }
    if(service === 'airport' && /charleroi/i.test(payload.destination || '') && !fixed){ exact = Number(p.airportCharleroi || 220); fixed = true; }
    const minutes = Math.max(10, Math.round(km * 1.25));
    const low = Math.round(exact * Number(p.confidenceMarginLow || 0.96));
    const high = Math.round(exact * Number(p.confidenceMarginHigh || 1.07));
    return {
      distanceKm: km,
      minutes,
      tariff: night ? 'Nacht' : 'Dag',
      service,
      fixed,
      low,
      high,
      exact: Number(exact.toFixed(2)),
      airportFee: hasAirport(`${payload.destination || ''} ${payload.pickup || ''}`) ? 1 : 0,
      longDistanceFee: km > 80 ? 1 : 0,
      label: fixed ? 'richtprijs' : 'prijsindicatie',
      needsControlTower: km > 80 || service === 'business' || service === 'vip' || service === 'long_distance'
    };
  }
  async function estimateSmart(payload){
    // Frontend estimate is the source of truth for visible client UX. API may exist, but should not make prices too high.
    return estimate(payload);
  }
  window.LV_PRICING = { suggestions, estimate, estimateSmart, isNight, bestPlace, fixedPriceFor, normalize, fixedPrices, allAutocompletePlaces };
})();
