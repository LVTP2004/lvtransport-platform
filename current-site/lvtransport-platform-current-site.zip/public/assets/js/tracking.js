(function(){
  const { $, escapeHtml, statusLabel } = window.LV || {};
  let eventSource = null;
  let map = null;
  let driverMarker = null;
  let pickupMarker = null;
  let destinationMarker = null;
  const ANTWERP = [51.2194, 4.4025];

  function getCode(){ return new URLSearchParams(location.search).get('code') || $('#trackingCode')?.value.trim() || ''; }
  function setStatus(status){ const pill=$('#trackingStatusPill'); if(pill){ pill.className=`status ${status||'pending'}`; pill.textContent=statusLabel(status); } }
  function sanitizeStatusList(timeline=[]){
    const seen = new Set();
    return [...timeline].reverse().filter(t=>{
      const key = `${t.status}-${String(t.at||'').slice(0,16)}`;
      if(seen.has(key)) return false;
      seen.add(key);
      return true;
    }).reverse().slice(-5);
  }
  function ensureMap(){
    const el = $('#trackingMap');
    if(!el || !window.L) return null;
    if(map) return map;
    el.innerHTML = '';
    map = L.map(el, { zoomControl: true, attributionControl: true }).setView(ANTWERP, 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap'
    }).addTo(map);
    setTimeout(()=>map.invalidateSize(), 250);
    return map;
  }
  function iconTaxi(){
    return L.divIcon({
      className: 'lv-taxi-marker',
      html: '<span>🚕</span>',
      iconSize: [42,42],
      iconAnchor: [21,21]
    });
  }
  function iconPoint(label){
    return L.divIcon({
      className: 'lv-point-marker',
      html: `<span>${label}</span>`,
      iconSize: [30,30],
      iconAnchor: [15,15]
    });
  }
  function renderMap(loc, booking){
    const el=$('#trackingMap');
    if(!el) return;
    if(!loc || !Number.isFinite(Number(loc.lat)) || !Number.isFinite(Number(loc.lng))){
      if(map){ map.remove(); map=null; driverMarker=null; pickupMarker=null; destinationMarker=null; }
      el.innerHTML='<div class="map-empty"><strong>GPS wordt voorbereid</strong><span>De live kaart verschijnt zodra de chauffeur locatie deelt.</span></div>';
      return;
    }
    const lat=Number(loc.lat), lng=Number(loc.lng);
    const m = ensureMap();
    if(!m) {
      el.innerHTML='<div class="map-empty">Kaartmodule kon niet laden. Open de locatie via Google Maps.</div>';
      return;
    }
    if(!driverMarker){
      driverMarker = L.marker([lat,lng], { icon: iconTaxi() }).addTo(m).bindPopup('LV chauffeur');
    } else {
      driverMarker.setLatLng([lat,lng]);
    }
    if(!pickupMarker){ pickupMarker = L.marker(ANTWERP, {icon:iconPoint('📍')}).addTo(m).bindPopup('Ophaalzone'); }
    const bounds = [driverMarker.getLatLng(), pickupMarker.getLatLng()];
    if(destinationMarker) bounds.push(destinationMarker.getLatLng());
    m.fitBounds(bounds, { padding:[40,40], maxZoom: 15 });

    let overlay = el.querySelector('.map-overlay.clean');
    if(!overlay){
      overlay = document.createElement('div');
      overlay.className='map-overlay clean';
      el.appendChild(overlay);
    }
    const update = loc.at ? new Date(loc.at).toLocaleTimeString('nl-BE', {hour:'2-digit', minute:'2-digit'}) : 'net';
    overlay.innerHTML = `<strong>🚕 Chauffeur locatie actief</strong><span>Laatste update: ${update}</span><a target="_blank" rel="noopener" href="https://maps.google.com/?q=${lat},${lng}">Open Google Maps</a>`;
  }
  function friendlyTitle(status, driverName){
    if(status === 'completed') return 'Uw rit is voltooid';
    if(status === 'arrived') return 'Uw chauffeur is aangekomen';
    if(status === 'driver_on_route' || status === 'in_progress') return 'Uw chauffeur is onderweg';
    if(driverName) return `${driverName} is toegewezen`;
    if(status === 'accepted') return 'Uw reservatie is geaccepteerd';
    return 'Reservatie ontvangen';
  }
  function renderBooking(b){
    $('#trackingTitle').textContent = friendlyTitle(b.status, b.driverName);
    setStatus(b.status);
    $('#trackingSummary').innerHTML = `<div class="success-card compact"><span class="eyebrow">Trackingcode</span><h2>${escapeHtml(b.code)}</h2><p>${escapeHtml(statusLabel(b.status))}</p></div>`;
    const timeline = sanitizeStatusList(b.timeline || []);
    $('#trackingDetails').innerHTML = `<div class="tracking-cards"><div><strong>Ophaaladres</strong><span>${escapeHtml(b.pickup)}</span></div><div><strong>Bestemming</strong><span>${escapeHtml(b.destination)}</span></div><div><strong>Datum & tijd</strong><span>${escapeHtml(b.date||'')} ${escapeHtml(b.time||'')}</span></div><div><strong>Chauffeur</strong><span>${escapeHtml(b.driverName || 'Nog niet toegewezen')}</span></div></div><div class="customer-timeline">${timeline.map(t=>`<div><span></span><strong>${escapeHtml(statusLabel(t.status))}</strong><small>${new Date(t.at).toLocaleString('nl-BE')}</small></div>`).join('')}</div>`;
    renderMap(b.driverLocation, b);
  }
  async function track(){
    const code=getCode(); if(!code) return;
    $('#trackingCode').value = code;
    if(eventSource){ eventSource.close(); eventSource=null; }
    try{
      const r = await window.LV_API.bookingByCode(code); renderBooking(r.booking);
      history.replaceState(null,'',`tracking.html?code=${encodeURIComponent(code)}`);
      eventSource = window.LV_API.trackEvents(code);
      ['booking','booking_updated','driver_location'].forEach(evt => {
        eventSource.addEventListener(evt, e=>{ try{ const data=JSON.parse(e.data); if(data.booking) renderBooking(data.booking); }catch{} });
      });
    } catch(err){
      $('#trackingSummary').innerHTML = `<div class="notice error">Code niet gevonden. Controleer uw 6 cijfers.</div>`;
      setStatus('cancelled');
      renderMap(null);
    }
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('#trackBtn')?.addEventListener('click', track);
    $('#trackingCode')?.addEventListener('keydown', e=>{if(e.key==='Enter') track();});
    if(getCode()) track();
  });
})();
