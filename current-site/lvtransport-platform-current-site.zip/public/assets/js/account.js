(function(){
  function setStatus(msg, type='info'){
    const el = document.getElementById('accountStatus'); if(!el) return; el.textContent = msg || ''; el.className = `auth-status ${type}`;
  }
  function renderBookings(bookings){
    document.getElementById('kpiBookings').textContent = bookings.length;
    document.getElementById('kpiActive').textContent = bookings.filter(b => !['completed','cancelled'].includes(b.status)).length;
    document.getElementById('kpiCompleted').textContent = bookings.filter(b => b.status === 'completed').length;
    const box = document.getElementById('bookingsList');
    if(!bookings.length){ box.innerHTML = '<p class="muted">Nog geen reservaties gevonden voor dit account.</p>'; return; }
    box.innerHTML = bookings.map(b => `<article class="booking-mini"><b>Code ${b.code}</b><div>${b.pickup || '-'} → ${b.destination || '-'}</div><div>${b.date || ''} ${b.time || ''} · Status: ${b.status || '-'}</div><a class="btn" href="tracking.html?code=${encodeURIComponent(b.code)}">Volg deze rit</a></article>`).join('');
  }
  async function load(){
    const auth = window.LV_CUSTOMER_AUTH;
    if(!auth || !auth.token()) { setStatus('Log in om uw reservaties te bekijken.'); return; }
    try{
      setStatus('Uw gegevens worden geladen...');
      const me = await auth.apiMe();
      const data = await auth.apiBookings();
      setStatus(`Ingelogd als ${me.customer?.email || 'klant'}.`, 'success');
      renderBookings(data.bookings || []);
    }catch(err){
      setStatus('Klantlogin is nog niet actief op de VPS of uw sessie is verlopen. Activeer eerst de server patch.', 'error');
    }
  }
  document.addEventListener('DOMContentLoaded', () => setTimeout(load, 300));
})();
